//
//  ProfileCollectionHeader.swift
//  Course2FinalTask
//
//  Created by Mykhailo Romanovskyi on 07.03.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//
import UIKit
import DataProvider

protocol NavigationFromProfileVC: class {
    func showFollowersTable()
    func showFollowingTable()
}

class ProfileCollectionHeader: UICollectionReusableView {
    
    weak var delegat: NavigationFromProfileVC?
    
        private lazy var currentUserImage: UIImageView = {
            let iv = UIImageView()
                iv.layer.cornerRadius = 35
                iv.clipsToBounds = true
                iv.backgroundColor = .red
            return iv
        }()
    
        private lazy var nameTextLabel: UILabel = {
            let nl = UILabel()
                nl.font = UIFont(name: "System", size: 14)
                nl.textAlignment = .center
                nl.textColor = .black
            return nl
        }()
        
        private lazy var followersLabel: UILabel = {
            let nl = UILabel()
                nl.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
                nl.textAlignment = .center
                nl.textColor = .black
                nl.isUserInteractionEnabled = true
            return nl
        }()
        
        private lazy var followingLabel: UILabel = {
            let nl = UILabel()
                nl.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
                nl.textAlignment = .center
                nl.textColor = .black
                nl.isUserInteractionEnabled = true
            return nl
        }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addElements()
        setConstraints()
        setGestureRecognizer()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension ProfileCollectionHeader {
    func setHeaderData(data: User) {
        currentUserImage.image = data.avatar
        nameTextLabel.text = data.fullName
        followersLabel.text = "Followers: " + String(data.followsCount)
        followingLabel.text = "Following: " + String(data.followedByCount)
    }
}

private extension ProfileCollectionHeader {
    
    func addElements() {
        addSubview(currentUserImage)
        addSubview(nameTextLabel)
        addSubview(followersLabel)
        addSubview(followingLabel)
    }
    
    func setConstraints() {
        currentUserImage.anchor(top: topAnchor, left: leadingAnchor, paddingTop: 8, paddingLeft: 8)
        currentUserImage.anchorSize(width: 70, height: 70)
        
        nameTextLabel.anchor(top: topAnchor, left: currentUserImage.trailingAnchor, paddingTop: 8, paddingLeft: 8)
        
        followersLabel.anchor(bottom: bottomAnchor, left: currentUserImage.trailingAnchor, paddingBottom: 8, paddingLeft: 8)
                   
        followingLabel.anchor( bottom: bottomAnchor, right: trailingAnchor,  paddingBottom: 8, paddingRight: 16)
    }
    
    func setGestureRecognizer() {
        let gestureFollowers = UITapGestureRecognizer(target: self, action: #selector(showFollowers))
        let gestureFollowing = UITapGestureRecognizer(target: self, action: #selector(showFollowing))
        followersLabel.addGestureRecognizer(gestureFollowers)
        followingLabel.addGestureRecognizer(gestureFollowing)
    }
    
   @objc func showFollowers() {
        delegat?.showFollowersTable()
    }
    
    @objc func showFollowing() {
        delegat?.showFollowingTable()
    }
}

