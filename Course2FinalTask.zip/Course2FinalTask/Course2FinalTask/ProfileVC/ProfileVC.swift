//
//  ProfileVC.swift
//  Course2FinalTask
//
//  Created by Mykhailo Romanovskyi on 06.03.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit
import DataProvider

private let headerIdentifier = "ProfileHeader"
private let cellIdentifier = "ProfileCell"
//let currentUser = DataProviders.shared.usersDataProvider.currentUser()
//let userData = DataProviders.shared.postsDataProvider.findPosts(by: currentUser.id)
//let followingCurrentUser = DataProviders.shared.usersDataProvider.usersFollowingUser(with: currentUser.id)
//let followedByCurrentUser = DataProviders.shared.usersDataProvider.usersFollowedByUser(with: currentUser.id)


class ProfileVC: UICollectionViewController {

    var isFollowing: Bool!
    var userData1: [Post] = [Post]()

    init(user: User = currentUser, userData: [Post] = userData!) {
        super.init(nibName: nil, bundle: nil)
        self.userData1 = userData
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        collectionView.register(ProfileCollectionHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: headerIdentifier)
        collectionView.register(ProfileCell.self, forCellWithReuseIdentifier: cellIdentifier)
     //   collectionView.collectionViewLayout = UICollectionViewFlowLayout()
        //почему надо добавлять?
        collectionView.backgroundColor = .white
        navigationItem.title = "Profile"
        //Так же не понадобились UIEdgeInsets, всё сразу работало хорошо
    }
}

extension ProfileVC {

    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {

        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerIdentifier, for: indexPath) as! ProfileCollectionHeader
        header.setHeaderData(data: currentUser)
        header.delegat = self
        return header
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return userData?.count ?? 0
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! ProfileCell
        guard let userData = userData else { return cell }
        cell.image = userData[indexPath.row].image
        return cell
    }
}

extension ProfileVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: view.frame.width, height: 86)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (view.frame.width - 2) / 3
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
}

extension ProfileVC: NavigationFromProfileVC {
    
    func showFollowersTable() {
        var data = [User]()
        if followedByCurrentUser != nil {
            data = followedByCurrentUser!
        }
        navigationController?.pushViewController(ProfileTV(data: data, navTitle: "Folowers"), animated: true)
    }
    
    func showFollowingTable() {
        navigationController?.pushViewController(ProfileTV(data: followingCurrentUser!, navTitle: "Following"), animated: true)
    }
    
    
}
