//
//  ProfileTV.swift
//  Course2FinalTask
//
//  Created by Mykhailo Romanovskyi on 08.03.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit
import DataProvider

private let tableViewCellIdentifier = "ProfileTVCell"

class ProfileTV: UIViewController {
    
    var dataForTable: [User]!
    var navigationTitle: String!
    let tableView = UITableView()
    
    init(data: [User], navTitle: String) {
        super.init(nibName: nil, bundle: nil)
        dataForTable = data
        navigationTitle = navTitle
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        setupTableView()
        navigationItem.title = navigationTitle
    }
}

private extension ProfileTV {
    func setupTableView() {
        
        view.addSubview(tableView)
        tableView.anchor(top: view.topAnchor, bottom: view.bottomAnchor, left: view.leadingAnchor, right: view.trailingAnchor)
        tableView.register(ProfileTVCell.self, forCellReuseIdentifier: tableViewCellIdentifier)
        tableView.separatorStyle = .singleLine
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 74.0, bottom: 0, right: 0.0)
        tableView.separatorInsetReference = .fromCellEdges
    }
}

extension ProfileTV: UITableViewDelegate, UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataForTable.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: tableViewCellIdentifier, for: indexPath) as! ProfileTVCell
        let bufferData = dataForTable[indexPath.row]
        cell.setCellProperty(image: bufferData.avatar!, text: bufferData.fullName)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let forUser = dataForTable[indexPath.row]
        let forPosts = DataProviders.shared.postsDataProvider.findPosts(by: forUser.id)
        
        navigationController?.pushViewController(ProfileVCTest(layout: UICollectionViewFlowLayout(), user: forUser, userData: forPosts!), animated: true)
    }
}
