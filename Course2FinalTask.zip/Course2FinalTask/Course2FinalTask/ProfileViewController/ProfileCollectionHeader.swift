//
//  ProfileCollectionHeader.swift
//  Course2FinalTask
//
//  Created by Mykhailo Romanovskyi on 07.03.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//
import UIKit
import DataProvider

protocol NavigationFromProfileViewController: class {
    func showFollowersTable()
    func showFollowingTable()
}

class ProfileCollectionHeader: UICollectionReusableView {
    
 weak var delegate: NavigationFromProfileViewController?
    
 private lazy var currentUserImage: UIImageView = {
        let imageview = UIImageView()
            imageview.layer.cornerRadius = 35
            imageview.clipsToBounds = true
            imageview.backgroundColor = .red
        return imageview
        }()
    
 private lazy var nameTextLabel: UILabel = {
        let label = UILabel()
            label.font = UIFont(name: "System", size: 14)
            label.textAlignment = .center
            label.textColor = .black
        return label
        }()
        
 private lazy var followersLabel: UILabel = {
        let label = UILabel()
            label.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
            label.textAlignment = .center
            label.textColor = .black
            label.isUserInteractionEnabled = true
        return label
        }()
        
 private lazy var followingLabel: UILabel = {
        let label = UILabel()
            label.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
            label.textAlignment = .center
            label.textColor = .black
            label.isUserInteractionEnabled = true
        return label
        }()
    
 override init(frame: CGRect) {
    super.init(frame: frame)
    addElements()
    setConstraints()
    setGestureRecognizer()
    }
    
 required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
    }
}

 extension ProfileCollectionHeader {
    
 func setHeaderData(data: User) {
    currentUserImage.image = data.avatar
    nameTextLabel.text = data.fullName
    followersLabel.text = "Followers: " + String(data.followsCount)
    followingLabel.text = "Following: " + String(data.followedByCount)
    }
}

private extension ProfileCollectionHeader {
    
 func addElements() {
    addSubview(currentUserImage)
    addSubview(nameTextLabel)
    addSubview(followersLabel)
    addSubview(followingLabel)
    }
    
 func setConstraints() {
    currentUserImage.anchor(top: topAnchor, left: leadingAnchor, paddingTop: 8, paddingLeft: 8)
    currentUserImage.anchorSize(width: 70, height: 70)
        
    nameTextLabel.anchor(top: topAnchor, left: currentUserImage.trailingAnchor, paddingTop: 8, paddingLeft: 8)
        
    followersLabel.anchor(bottom: bottomAnchor, left: currentUserImage.trailingAnchor, paddingBottom: 8, paddingLeft: 8)
                   
    followingLabel.anchor( bottom: bottomAnchor, right: trailingAnchor,  paddingBottom: 8, paddingRight: 16)
    }
    
 func setGestureRecognizer() {
    let gestureFollowers = UITapGestureRecognizer(target: self, action: #selector(showFollowers))
    let gestureFollowing = UITapGestureRecognizer(target: self, action: #selector(showFollowing))
    followersLabel.addGestureRecognizer(gestureFollowers)
    followingLabel.addGestureRecognizer(gestureFollowing)
    }
    
 @objc func showFollowers() {
    delegate?.showFollowersTable()
    }
    
 @objc func showFollowing() {
    delegate?.showFollowingTable()
    }
}

