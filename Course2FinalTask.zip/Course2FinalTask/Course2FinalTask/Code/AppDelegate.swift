//
//  AppDelegate.swift
//  Course2FinalTask
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        assembly()
        return true
    }
}

private extension AppDelegate {
    func assembly() {
        window = UIWindow(frame: UIScreen.main.bounds)
        let tabBarController = UITabBarController()
            
        
        let feedVC = UINavigationController(rootViewController: FeedVC(collectionViewLayout: UICollectionViewFlowLayout()))
        feedVC.tabBarItem.image = #imageLiteral(resourceName: "feed")
        feedVC.tabBarItem.title = "Feed"
        
//        let profileVC = UINavigationController(rootViewController: ProfileVC(collectionViewLayout: UICollectionViewFlowLayout()))
        
        let profileVC = UINavigationController(rootViewController: ProfileVCTest(layout: UICollectionViewFlowLayout()))
        
        profileVC.tabBarItem.image = #imageLiteral(resourceName: "profile")
        profileVC.tabBarItem.title = "Profile"
        
        tabBarController.viewControllers = [feedVC, profileVC]
        
        window?.rootViewController = tabBarController
        window?.makeKeyAndVisible()
    }
}
