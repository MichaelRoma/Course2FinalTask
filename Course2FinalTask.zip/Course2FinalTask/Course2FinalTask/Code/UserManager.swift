//
//  UserData.swift
//  Course2FinalTask
//
//  Created by Mykhailo Romanovskyi on 21.03.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import Foundation
import DataProvider

struct UserManager {
    
static var feedData = DataProviders.shared.postsDataProvider.feed()
static let buffer = DataProviders.shared.postsDataProvider
    
static let currentUser = DataProviders.shared.usersDataProvider.currentUser()
static let userData = DataProviders.shared.postsDataProvider.findPosts(by: currentUser.id)
static  let followingCurrentUser = DataProviders.shared.usersDataProvider.usersFollowingUser(with: currentUser.id)
static let followedByCurrentUser = DataProviders.shared.usersDataProvider.usersFollowedByUser(with: currentUser.id)
    
    private init() {}
}
