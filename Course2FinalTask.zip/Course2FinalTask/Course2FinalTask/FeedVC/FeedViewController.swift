//
//  FeedVC.swift
//  Course2FinalTask
//
//  Created by Mykhailo Romanovskyi on 06.03.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit
import DataProvider


class FeedViewController: UICollectionViewController {
 private let reuseIdentifier = "FeedCell"
    
 override func viewDidLoad() {
    super.viewDidLoad()
    
    collectionView.register(FeedCell.self, forCellWithReuseIdentifier: reuseIdentifier)
    collectionView.backgroundColor = .white
    navigationItem.title = "Feed"
    }

 override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return UserManager.feedData.count
    }

 override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! FeedCell
        cell.setupAllData(data: UserManager.feedData[indexPath.item], indexParhRow: indexPath.item)
        cell.delegate = self
    return cell
    }
}

extension FeedViewController: UICollectionViewDelegateFlowLayout {

 func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    let width = view.frame.width
    return CGSize(width: width, height: 550)
    }

 func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
    return 0
    }

 func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {        return 0
    }
}

extension FeedViewController: NavigationFromFeedVC {
    
 func didPressButtonX(feedCell: FeedCell) {
    switch feedCell.heartButton.tintColor {
    case UIColor.lightGray:
        UserManager.feedData[feedCell.indexPathItem].likedByCount += 1
        _ = UserManager.buffer.likePost(with: feedCell.id)
        feedCell.likes.text = "Likes: " + String(UserManager.feedData[feedCell.indexPathItem].likedByCount)
        feedCell.heartButton.tintColor = .systemBlue
    case UIColor.systemBlue:
        UserManager.feedData[feedCell.indexPathItem].likedByCount -= 1
        _ = UserManager.buffer.unlikePost(with: feedCell.id)
        feedCell.likes.text = "Likes: " + String(UserManager.feedData[feedCell.indexPathItem].likedByCount)
        feedCell.heartButton.tintColor = .lightGray
    default:
            print("Something went wrong")
    }
 }
    
 func didPressUserPic(feedCell: FeedCell) {
    let animation = CAKeyframeAnimation(keyPath: #keyPath(CALayer.opacity))
        let values = [0, 1, 0]
        let timeFrames = [0.1, 0.2, 0.3]
        animation.values = values
        animation.keyTimes = timeFrames as [NSNumber]
        animation.duration = 3
        let firstStep = CAMediaTimingFunction(name: .linear)
        let secondStep = CAMediaTimingFunction(name: .default)
        let thirdStep = CAMediaTimingFunction(name: .easeOut)
        animation.timingFunctions = [firstStep, secondStep, thirdStep]
        feedCell.bigLike.layer.add(animation, forKey: nil)
        
    if feedCell.heartButton.tintColor == UIColor.lightGray {
        UserManager.feedData[feedCell.indexPathItem].likedByCount += 1
        _ = UserManager.buffer.likePost(with: feedCell.id)
        feedCell.likes.text = "Likes: " + String(UserManager.feedData[feedCell.indexPathItem].likedByCount)
        feedCell.heartButton.tintColor = .systemBlue
        }
 }
    
 func didPressAvatarOrUserName(userID: User.Identifier) {
    guard let user = DataProviders.shared.usersDataProvider.user(with: userID) else { return }
    guard let post = DataProviders.shared.postsDataProvider.findPosts(by: userID) else { return }
    navigationController?.pushViewController(ProfileViewController(layout: UICollectionViewFlowLayout(), user: user, userData: post), animated: true)
    }
    
 func didPressLikes(id: Post.Identifier) {
    guard let data = DataProviders.shared.postsDataProvider.usersLikedPost(with: id) else { return }
    var arData = [User]()
    for item in data {
        if let buffer = DataProviders.shared.usersDataProvider.user(with: item) { arData.append(buffer) }
        }
    navigationController?.pushViewController(ProfileTableView(data: arData, navTitle: "Likes"), animated: true)
    }
}
